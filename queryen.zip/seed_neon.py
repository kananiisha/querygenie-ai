"""
Seed script for Neon PostgreSQL database.
Run with Neon URL set:
  $env:DATABASE_URL="your_neon_url"
  python seed_neon.py
"""

import os
from sqlalchemy import create_engine, text

DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///./querygenie_dev.db")
engine = create_engine(DATABASE_URL)

with engine.connect() as conn:
    # Create tables
    conn.execute(text("""
        CREATE TABLE IF NOT EXISTS customers (
            customer_id SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            city VARCHAR(50),
            signup_date DATE NOT NULL
        )
    """))
    conn.execute(text("""
        CREATE TABLE IF NOT EXISTS products (
            product_id SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            category VARCHAR(50) NOT NULL,
            price NUMERIC(10,2) NOT NULL
        )
    """))
    conn.execute(text("""
        CREATE TABLE IF NOT EXISTS orders (
            order_id SERIAL PRIMARY KEY,
            customer_id INTEGER NOT NULL,
            order_date DATE NOT NULL,
            status VARCHAR(20) NOT NULL
        )
    """))
    conn.execute(text("""
        CREATE TABLE IF NOT EXISTS order_items (
            order_item_id SERIAL PRIMARY KEY,
            order_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            unit_price NUMERIC(10,2) NOT NULL
        )
    """))
    conn.execute(text("""
        CREATE TABLE IF NOT EXISTS payments (
            payment_id SERIAL PRIMARY KEY,
            order_id INTEGER NOT NULL,
            amount NUMERIC(10,2) NOT NULL,
            payment_method VARCHAR(20) NOT NULL,
            payment_date DATE NOT NULL,
            status VARCHAR(20) NOT NULL
        )
    """))

    # Seed data using PostgreSQL syntax
    conn.execute(text("""
        INSERT INTO customers (customer_id, name, email, city, signup_date) VALUES
        (1,'Priya Sharma','priya.sharma@mail.com','Ahmedabad','2025-01-12'),
        (2,'Rohan Mehta','rohan.mehta@mail.com','Mumbai','2025-02-03'),
        (3,'Sneha Patel','sneha.patel@mail.com','Ahmedabad','2025-02-20'),
        (4,'Arjun Verma','arjun.verma@mail.com','Delhi','2025-03-05'),
        (5,'Kavya Nair','kavya.nair@mail.com','Bangalore','2025-03-18'),
        (6,'Vivek Joshi','vivek.joshi@mail.com','Pune','2025-04-02'),
        (7,'Anjali Desai','anjali.desai@mail.com','Surat','2025-04-15'),
        (8,'Karan Singh','karan.singh@mail.com','Delhi','2025-05-01'),
        (9,'Meera Iyer','meera.iyer@mail.com','Chennai','2025-05-22'),
        (10,'Aditya Rao','aditya.rao@mail.com','Bangalore','2025-06-10')
        ON CONFLICT DO NOTHING
    """))

    conn.execute(text("""
        INSERT INTO products (product_id, name, category, price) VALUES
        (1,'Wireless Earbuds','Electronics',1499.00),
        (2,'Smartwatch','Electronics',2999.00),
        (3,'Bluetooth Speaker','Electronics',1799.00),
        (4,'Cotton T-Shirt','Clothing',499.00),
        (5,'Denim Jacket','Clothing',1999.00),
        (6,'Running Shoes','Clothing',2499.00),
        (7,'Non-stick Pan','Home',899.00),
        (8,'LED Desk Lamp','Home',699.00),
        (9,'Bedsheet Set','Home',1299.00),
        (10,'Fiction Novel','Books',349.00),
        (11,'Self-Help Book','Books',299.00),
        (12,'Notebook Set','Books',199.00)
        ON CONFLICT DO NOTHING
    """))

    conn.execute(text("""
        INSERT INTO orders (order_id, customer_id, order_date, status) VALUES
        (1,1,'2025-04-01','delivered'),
        (2,2,'2025-04-03','delivered'),
        (3,3,'2025-04-10','cancelled'),
        (4,1,'2025-04-15','delivered'),
        (5,4,'2025-04-20','shipped'),
        (6,5,'2025-05-02','delivered'),
        (7,6,'2025-05-05','delivered'),
        (8,2,'2025-05-10','placed'),
        (9,7,'2025-05-14','delivered'),
        (10,8,'2025-05-20','delivered'),
        (11,3,'2025-05-25','delivered'),
        (12,9,'2025-06-01','shipped'),
        (13,10,'2025-06-05','delivered'),
        (14,4,'2025-06-08','placed'),
        (15,5,'2025-06-12','delivered')
        ON CONFLICT DO NOTHING
    """))

    conn.execute(text("""
        INSERT INTO order_items (order_item_id, order_id, product_id, quantity, unit_price) VALUES
        (1,1,1,1,1499.00),(2,1,4,2,499.00),(3,2,2,1,2999.00),
        (4,3,6,1,2499.00),(5,4,7,1,899.00),(6,4,8,1,699.00),
        (7,5,5,1,1999.00),(8,6,1,2,1499.00),(9,7,9,1,1299.00),
        (10,8,3,1,1799.00),(11,9,10,3,349.00),(12,10,2,1,2999.00),
        (13,10,11,1,299.00),(14,11,6,1,2499.00),(15,12,1,1,1499.00),
        (16,13,4,3,499.00),(17,13,12,2,199.00),(18,14,5,1,1999.00),
        (19,15,3,2,1799.00)
        ON CONFLICT DO NOTHING
    """))

    conn.execute(text("""
        INSERT INTO payments (payment_id, order_id, amount, payment_method, payment_date, status) VALUES
        (1,1,2497.00,'upi','2025-04-01','success'),
        (2,2,2999.00,'card','2025-04-03','success'),
        (3,3,2499.00,'upi','2025-04-10','failed'),
        (4,4,1598.00,'card','2025-04-20','success'),
        (5,5,1999.00,'netbanking','2025-04-20','success'),
        (6,6,2998.00,'upi','2025-05-02','success'),
        (7,7,1299.00,'cod','2025-05-05','success'),
        (8,8,1799.00,'card','2025-05-14','success'),
        (9,9,1047.00,'upi','2025-06-01','success'),
        (10,10,3298.00,'card','2025-06-05','success'),
        (11,11,2499.00,'upi','2025-05-25','success'),
        (12,12,1499.00,'cod','2025-06-01','pending'),
        (13,13,1895.00,'upi','2025-06-08','success'),
        (14,14,1999.00,'netbanking','2025-06-08','success'),
        (15,15,3598.00,'card','2025-06-12','success')
        ON CONFLICT DO NOTHING
    """))

    conn.commit()
    print("Neon PostgreSQL DB seeded successfully with all 5 tables!")
